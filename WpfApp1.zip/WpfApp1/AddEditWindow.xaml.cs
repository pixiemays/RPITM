﻿using System;
using System.Linq;
using System.Windows;

namespace WpfApp1
{
    public partial class AddEditWindow : Window
    {
        private Payment _currentPaym = new Payment();
        
        public AddEditWindow(Payment selectedPayment)
        {
            InitializeComponent();

            if (selectedPayment != null)
            {
                _currentPaym = selectedPayment;
            }
            
            DataContext = _currentPaym;
            
            cbCategory.ItemsSource = PaymentsBaseEntities.GetContext().Category.ToList();
            cbFIO.ItemsSource = PaymentsBaseEntities.GetContext().User.ToList();
            
            if (_currentPaym.id == 0)
            {
                PaymentsBaseEntities.GetContext().Payment.Add(_currentPaym);
            }
        }
        
        private void SaveBtn(object sender, RoutedEventArgs e)
        {
            try
            {
                PaymentsBaseEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}