﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PaymentsBaseEntities _context = new PaymentsBaseEntities();
        
        public MainWindow()
        {
            InitializeComponent();
                
            DG.ItemsSource = PaymentsBaseEntities.GetContext().Payment.ToList();
        }

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditWindow addEditWindow = new AddEditWindow(null);
            addEditWindow.ShowDialog();
        }

        private void Edit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditWindow addEditWindow = new AddEditWindow((sender as Button).DataContext as Payment);
            addEditWindow.ShowDialog();
        }

        private void Delete_OnClick(object sender, RoutedEventArgs e)
        {
            var paymentForDel = DG.SelectedItems.Cast<Payment>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие элементы ({paymentForDel.Count()})",
                    "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (var p in paymentForDel)
                    {
                        PaymentsBaseEntities.GetContext().Payment.Remove(p);
                    }
                    PaymentsBaseEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DG.ItemsSource = PaymentsBaseEntities.GetContext().Payment.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
